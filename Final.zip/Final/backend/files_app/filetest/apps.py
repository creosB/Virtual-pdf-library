from django.apps import AppConfig


class FiletestConfig(AppConfig):
    name = 'filetest'
