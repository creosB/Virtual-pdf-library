from django.contrib import admin
from filetest.models import Files

# Register your models here.

admin.site.register(Files)