from django.apps import AppConfig


class FileapiConfig(AppConfig):
    name = 'fileapi'
