# Code of Raymond Hettinger Slides for Public Talks

# Modern solvers Problems well-defined are problems solved - PyCon 2019
# PYCON 2019 USA at https://www.youtube.com/watch?v=_GP9OpZPUYc 
# see https://rhettinger.github.io/

